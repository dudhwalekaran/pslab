	MATLAB-BASED  VERSATILE POWER FLOW PROGRAMMES
	------------------------------------------------------------------
	A) Folder name: NR_programmes.

	This folder contains 5 MATLAB files to carryout power flow analysis based 
	on Newton-Raphson method. This programme permits load flow run with and 
	without accounting Q-limits at PV-buses.

	-----------------------------
	B) Folder name: FDLF_programmes.

	This folder contains 7 MATLAB files to carryout power flow analysis based 
	on Fast-Decoupled method.

	Features of the programme are as follows:

	1. Permits handling of Q-limits at PV-buses.
	2. Permits handling of polynomial expression-based static load models.
	    (a) Voltage-dependent load models.
	    (b) Frequency-dependent load models. 
        3. Permits modelling of multiple two-terminal HVDC links in a power system.
	-------------------------------

	C) Folder name: Example_systems.

  	It contains the following sub-folders:

 	1. 4_bus-example: This is a 4-bus system (Example 9.2) taken from the book 
 	    `Power System Analysis' by J.J Grainger and W.D. Stevenson 
 	     McGraw Hill Inc. NY, 1994.

 	2. IEEE_systems: It contains data files for the following IEEE test system :

	(source: (i) Power system test archive UWEE: www.ee.washington.edu/research/pstca
        	 (ii) IEEE committee report, ``Transient stability test systems for direct 
            	     stability methods'', IEEE Trans. PS, Vol. 7, pp37-43, Feb., 1992)
    	a)  14-bus 
    	b)  30-bus
    	c)  57-bus
    	d) 118-bus
    	e) 145-bus
    	f) 162-bus
    	g) 300-bus 
	--------------------------------
	D) File name of the manual : manual_LF.pdf