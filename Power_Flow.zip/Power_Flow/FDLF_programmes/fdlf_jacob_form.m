%~~~~~~~~~~~~~Form Jacobian and solve for bus voltages and angles~~~~~~~~~~%
Vmag=sparse(ones(nb,1));
Vang=sparse(zeros(nb,1));
Vmag(pv_data(:,1))=pv_data(:,2);  %Replaces the voltages of P-V buses in Vmag 
Vmag(sl) = Vsl;
Vang(sl) = 0;
Vo=Vmag;
kp = 0;
kq = 0;
fid=fopen('report.dat', 'w');
fprintf(fid,'                   Detailed Report of Load flow (FDLF method)\n' ); 
fprintf(fid,'                   ----------------------------\n' ); 

%------------------Iteration begins from here onwards---------------------%
for k=1:300
   Vbus=Vmag.*(cos(Vang)+ j*sin(Vang));
%----------------------------------bus powers calculations----------------%
   S=Vbus.*(conj(Y*Vbus));
   Pc=real(S);
   Qc=imag(S);
%---------------------finding non slack and non pv buses------------------%
   pv_num=pv_data(:,1);
   pv_sl_num=[pv_num;sl];
   num_no_sl_pv =[1:nb]'; 
   num_no_sl_pv(pv_sl_num,:)=[];
%---------------------Load modelling starts here-------------------------%
   
   Pdc =  sparse(zeros(nb,1));
   Qdc =  sparse(zeros(nb,1));
   if (nl~=0)
    dcflow;
    Pdc([Re_bus;In_bus]) = [Pr;-Pi];
    Qdc([Re_bus;In_bus]) = [Qr;Qi];
   end 
   
   if (Load_bit==0&nl~=0)
    Psp = sparse(zeros(nb,1));
    Psp(pv_data(:,1)) = pv_data(:,3);
    Psp(pq_data(:,1)) = Psp(pq_data(:,1))-pq_data(:,2);
    Qsp = sparse(zeros(nb,1));
    Qsp(pq_data(:,1)) = -pq_data(:,3);
    Qload =sparse(zeros(nb,1));
    Qload(pq_data(:,1))= pq_data(:,3);
   
    Psp([Re_bus;In_bus]) = Psp([Re_bus;In_bus])- Pdc([Re_bus;In_bus]); 
    Qsp([Re_bus;In_bus]) = Qsp([Re_bus;In_bus])- Qdc([Re_bus;In_bus]); 
    Qload([Re_bus;In_bus]) = Qload([Re_bus;In_bus]) + Qdc([Re_bus;In_bus]);
   end

   if(Load_bit~=0)
    PL = sparse(zeros(nb,1));
    PL_cp = a1.*PLo;
    PL_cc = a2.*PLo.*(Vmag./Vo);
    PL_ci = a3.*PLo.*(Vmag./Vo).^2;
    PL = PL_cp + PL_cc + PL_ci; 
   
    QL = sparse(zeros(nb,1));
    QL_cp = b1.*QLo;
    QL_cc = b2.*QLo.*(Vmag./Vo);
    QL_ci = b3.*QLo.*(Vmag./Vo).^2;
    QL = QL_cp + QL_cc + QL_ci; 
   
    Psp = sparse(zeros(nb,1));
    Psp(pv_data(:,1)) = pv_data(:,3);
    Psp(pq_data(:,1)) = Psp(pq_data(:,1))-PL(pq_data(:,1));
    Psp([Re_bus;In_bus])= Psp([Re_bus;In_bus])- Pdc([Re_bus;In_bus]);

    Qsp = sparse(zeros(nb,1));
    Qsp(pq_data(:,1)) = -QL(pq_data(:,1));
    Qsp([Re_bus;In_bus]) =Qsp([Re_bus;In_bus]) - Qdc([Re_bus;In_bus]);
   end    %-----------Load modelling ends here---------%
   
   if (Freq_bit~= 0)
    if(Load_bit==0) 
     PL = PLo;
     QL = QLo;
    end
    
    Psp_sl  = PG_sl - PL(sl);
    delP_D = Pc(sl) - Psp_sl;
    delF = delF + (-delP_D*R);
     
    PL = PL*(1 + Kpf*delF);
    QL = QL*(1 + Kqf*delF);
     
    Psp = sparse(zeros(nb,1));
    Psp(pv_data(:,1)) = pv_data(:,3);
    Psp(pq_data(:,1)) = Psp(pq_data(:,1))-PL(pq_data(:,1));
    Psp([Re_bus;In_bus])= Psp([Re_bus;In_bus])- Pdc([Re_bus;In_bus]);

    Qsp = sparse(zeros(nb,1));
    Qsp(pq_data(:,1)) = -QL(pq_data(:,1));
    Qsp([Re_bus;In_bus]) =Qsp([Re_bus;In_bus]) - Qdc([Re_bus;In_bus]);
   end
   
 %------------------------bus power mis matches -------------------------%  
   delP=Psp-Pc;
   delP(sl,:)=[];
   delQ=Qsp-Qc;
   delQ(pv_sl_num,:)=[];
   
   if (Freq_bit~= 0)
    Psp_sl  = PG_sl - PL(sl);
    delP_sl = Pc(sl) - Psp_sl;
    nosl_check = (max(abs(delP))<= tole);
    sl_check =  (abs(delP_sl)<= tole);
    del_P_sl = [delP;delP_sl];
   else
    nosl_check = (max(abs(delP))<= tole);
    sl_check = 1;
    del_P_sl = delP;
   end

   if (nosl_check~=0 & sl_check~=0)
     if (max(abs(delQ))<= tole)
      fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
      fprintf(fid,'Converged Real power mismatch iteration No = %i, Max.mismatch = %10.8f\n',kp, full(max(abs(del_P_sl))));
      fprintf(fid,'Converged Reactive power mismatch iteration No = %i, Max. mismatch = %10.8f\n',kq, full(max(abs(delQ))));
      convergence_bit=1;
      if(sum(pvpq(:,1)==sl)==1&(Load_bit~=0|Freq_bit~=0))
       S(sl)= S(sl)+PL(sl)+j*QL(sl)+Pdc(sl)+j*Qdc(sl);
      else
       S(sl)= S(sl)+(sl_load(1,2)+j*sl_load(1,3))+Pdc(sl)+j*Qdc(sl);
      end
      fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
      break;
     end
   else
    kp=kp+1;
    if(k~=1)
     del_Pm=sparse(zeros(nb,1)); 
     del_Pm(sort([pv_num;num_no_sl_pv]))=delP;
     
     if (Freq_bit~= 0)
       del_Pm(sl) = delP_sl;
     end
      
     Bno=[1:nb]';
     vio_busP = Bno(abs(del_Pm)==max(abs(del_Pm)));
     fprintf(fid,'Iter. No = %i Max. Real power mismatch at bus = %i, Max. mismatch = %10.8f\n',(kp-1),full(vio_busP),full(max(abs(del_Pm))));
    end
    
 %---------------------Updation of bus angles at each bus------------------% 
    del_Vang = Bd\(delP./Vmag(num_nosl));
    
    Vang(num_nosl)=Vang(num_nosl)+ del_Vang;
   end
 %--------------------Updation of bus voltages at each bus-----------------% 
   Vbus = Vmag.*(cos(Vang)+ j*sin(Vang));
   S=Vbus.*(conj(Y*Vbus));
   Qc = imag(S);
   delQ=Qsp-Qc;
   delQ(pv_sl_num,:)=[];
         
   
  %-----------Perform the following if Q-limit is accounted--------------%
    pv_num_Uvio=sparse(zeros(nb,1));
    pv_num_Lvio=sparse(zeros(nb,1));
    
    Qstart_cri = 0.1;
    if (Q_bit~=0 & max(abs(delQ))<=Qstart_cri)
     if(Load_bit~=0 | Freq_bit~= 0)  
      Qc(pvpq_buses) = Qc(pvpq_buses) + QL(pvpq_buses); 
      Qc(pvpq_buses) = Qc(pvpq_buses) + Qdc(pvpq_buses);  
     else
      Qc(pvpq_buses) = Qc(pvpq_buses) + Qload(pvpq_buses); 
     end
   %----------------------checking Qlimit voilation-----------------------%
     if (sum(Qc(pv_num)>QUlim(pv_num))>=1)
      pv_num_Uvio(pv_num)=[Qc(pv_num)>QUlim(pv_num)];
        
      pv_num=[pv_num(Qc(pv_num)<QUlim(pv_num))];
      pv_sl_num=[pv_num;sl];
      num_no_sl_pv = [1:nb]';
      num_no_sl_pv(pv_sl_num,:)=[];
     end
        
     if (sum(Qc(pv_num)<QLlim(pv_num))>=1)
      pv_num_Lvio(pv_num) =[Qc(pv_num)<QLlim(pv_num)];
        
      pv_num=[pv_num(Qc(pv_num)>QLlim(pv_num))];
      pv_sl_num=[pv_num;sl];
      num_no_sl_pv = [1:nb]';
      num_no_sl_pv(pv_sl_num,:)=[];
     end
        
     Qsp = sparse(zeros(nb,1));
     if(Load_bit~=0 | Freq_bit~= 0)
      Qsp(pq_data(:,1)) = -QL(pq_data(:,1));
      Qsp([Re_bus;In_bus]) = Qsp([Re_bus;In_bus])- Qdc([Re_bus;In_bus]); 
     else  
      Qsp(pq_data(:,1)) = -pq_data(:,3);
      Qsp([Re_bus;In_bus]) = Qsp([Re_bus;In_bus])- Qdc([Re_bus;In_bus]); 
     end 
     
     Vmag(pv_num)=pv_Vmag(pv_num); 
     if(Load_bit~=0)
      PL_cp(pvpq_buses) = a1(pvpq_buses).*PLo(pvpq_buses);
      PL_cc(pvpq_buses) = a2(pvpq_buses).*PLo(pvpq_buses).*(Vmag(pvpq_buses)./Vo(pvpq_buses));
      PL_ci(pvpq_buses) = a3(pvpq_buses).*PLo(pvpq_buses).*(Vmag(pvpq_buses)./Vo(pvpq_buses)).^2;
      PL = PL_cp + PL_cc + PL_ci; 
      
      QL_cp(pvpq_buses) = b1(pvpq_buses).*QLo(pvpq_buses);
      QL_cc(pvpq_buses) = b2(pvpq_buses).*QLo(pvpq_buses).*(Vmag(pvpq_buses)./Vo(pvpq_buses));
      QL_ci(pvpq_buses) = b3(pvpq_buses).*QLo(pvpq_buses).*(Vmag(pvpq_buses)./Vo(pvpq_buses)).^2;
      QL = QL_cp + QL_cc + QL_ci; 
      
      if (Freq_bit~= 0)
       PL = PL*(1 + Kpf*delF);
       QL = QL*(1 + Kqf*delF);
      end
               
      
      Psp = sparse(zeros(nb,1));
      Psp(pv_data(:,1)) = pv_data(:,3);
      Psp(pq_data(:,1)) = Psp(pq_data(:,1))-PL(pq_data(:,1));
      Psp([Re_bus;In_bus])= Psp([Re_bus;In_bus])- Pdc([Re_bus;In_bus]);

      Qsp = sparse(zeros(nb,1));
      Qsp(pq_data(:,1)) = -QL(pq_data(:,1));
      Qsp([Re_bus;In_bus]) = Qsp([Re_bus;In_bus])- Qdc([Re_bus;In_bus]);
     end 
         
     Qsp = Qsp + (pv_num_Uvio.*QUlim)+ (pv_num_Lvio.*QLlim);  
     
   %------------------------Re-calculation of bus powers --------------------%
     Vbus=Vmag.*(cos(Vang)+ j*sin(Vang));
     S=Vbus.*(conj(Y*Vbus));
     Qc = imag(S);
    end       %----------------Q-limit part ends here----------------------%
    
    delP=Psp-real(S);
    delP(sl,:)=[];
    delQ=Qsp-Qc;
    delQ(pv_sl_num,:)=[];

    if (max(abs(delQ))<= tole)
    if (Freq_bit~= 0)
     Psp_sl  = PG_sl - PL(sl);
     delP_sl = Pc(sl) - Psp_sl;
     nosl_check = (max(abs(delP))<= tole);
     sl_check =  (abs(delP_sl)<= tole);
     del_P_sl = [delP;delP_sl];
    else
     nosl_check = (max(abs(delP))<= tole);
     sl_check = 1;
     del_P_sl = delP;
    end
    if (nosl_check~=0 & sl_check~=0)
     fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
     fprintf(fid,'Converged Real power mismatch iteration No = %i, Max.mismatch = %10.8f\n',kp, full(max(abs(del_P_sl))));
     fprintf(fid,'Converged Reactive power mismatch iteration No = %i, Max. mismatch = %10.8f\n',kq, full(max(abs(delQ))));
     convergence_bit=1;
     if(sum(pvpq(:,1)==sl)==1&(Load_bit~=0|Freq_bit~=0))
      S(sl)= S(sl)+PL(sl)+j*QL(sl)+Pdc(sl)+j*Qdc(sl);
     else
      S(sl)= S(sl)+(sl_load(1,2)+j*sl_load(1,3))+Pdc(sl)+j*Qdc(sl);
     end
     
     fprintf(fid,'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n');
     break;
    end
   else
    kq = kq+1; 
    if(k~=1)
     del_Qm=sparse(zeros(nb,1));
     del_Qm(num_no_sl_pv)=delQ;
     Bno=[1:nb]';
     vio_busQ=Bno(abs(del_Qm)==max(abs(del_Qm)));
     fprintf(fid,'Iter. No = %i Max. Reactive power mismatch at bus = %i, Max. mismatch = %10.8f\n',(kq-1),full(vio_busQ),full(max(abs(del_Qm))));
   end
  
   Bdd = Bdd_bus;
   Bdd(:,pv_sl_num)=[];
   Bdd(pv_sl_num,:)=[];
   
   del_Vmag = Bdd\(delQ./Vmag(num_no_sl_pv));
    
   Vmag(num_no_sl_pv)=Vmag(num_no_sl_pv) + del_Vmag;
    
   if (sum(pv_num_Uvio + pv_num_Lvio)~=0)
    pv_Vmag(pv_data(:,1)) = Vmag(pv_data(:,1));
   end
  end
end

fclose(fid);



