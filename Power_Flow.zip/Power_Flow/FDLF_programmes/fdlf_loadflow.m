clear all;
clc
t0=clock;
convergence_bit=0;    % this bit will be set to 1 if convergence is reached.
%----------------------------------Load the system data--------------------------%
load busno.dat;
load nt.dat;
load pvpq.dat;
%--------------------------------------------------------------------------------%
sl=busno(1);
tole=busno(2);
nb=busno(3);
nline=busno(4);
ntrans=busno(5);
npv=busno(6);
Q_bit=busno(7);
Load_bit=busno(8);
Freq_bit = busno(9);
npq=busno(10);                                                                                                                                                                          
nshunt=busno(11);
Vsl=busno(12);
nl = busno(13);

if (nshunt~=0)
  load shunt.dat;
end   
if (Q_bit~=0)
  load Qlim_data.dat;
end 
if (Load_bit~=0)
  load load_model.dat;
end

pv_data=pvpq(1:npv,:);      %P-V bus data
load_data=pvpq(npv+1:npv+npq,:); % load data
pq_data = load_data((load_data(:,1)~=sl),:);  %P-Q bus data

pv=sparse(zeros(nb,1));
pq=sparse(zeros(nb,1));
pv(pv_data(:,1))=pv_data(:,1);
pq(pq_data(:,1))=pq_data(:,1);
pvpq_buses=pq(pv==pq);   
pvpq_buses((pvpq_buses==0),:)=[]; %pvpq bus nos


sl_load=sparse(zeros(1,3));
if(sum(pvpq(:,1)==sl)==1)
  sl_load=pvpq((pvpq(:,1)==sl),:);   %slack bus load data
end


num_nosl = [1:nb]';
num_nosl(sl,:) = [];    

%-----------------Call dcdata.m to read Hvdc link input data----------------------%

if (nl~=0)
  dcdata;
else
   Re_bus = 1;
   In_bus = 2; % dummy  bus numbers
end   

%------------------------call B_bus_form.m  to construct the Bd and Bdd matrices-----%
B_bus_form;       
%--------------------------------------------------------------------------%
if (Load_bit~=0)
 PLo = sparse(zeros(nb,1));
 PLo(load_data(:,1)) = load_data(:,2);
 a1 = sparse(zeros(nb,1));
 a2 = sparse(zeros(nb,1));
 a3 = sparse(zeros(nb,1));
 a1(load_data(:,1)) = 1;
 a1(load_model(:,1)) = load_model(:,2);
 a2(load_model(:,1)) = load_model(:,3);
 a3(load_model(:,1)) = load_model(:,4);

 QLo = sparse(zeros(nb,1));
 QLo(load_data(:,1)) = load_data(:,3);
 b1 = sparse(zeros(nb,1));
 b2 = sparse(zeros(nb,1));
 b3 = sparse(zeros(nb,1));
 b1(load_data(:,1)) = 1;
 b1(load_model(:,1)) = load_model(:,5);
 b2(load_model(:,1)) = load_model(:,6);
 b3(load_model(:,1)) = load_model(:,7);
else
 Psp = sparse(zeros(nb,1));
 Psp(pv_data(:,1)) = pv_data(:,3);
 Psp(pq_data(:,1)) = Psp(pq_data(:,1))-pq_data(:,2);
 Qsp = sparse(zeros(nb,1));
 Qsp(pq_data(:,1)) = -pq_data(:,3);
 Qload =sparse(zeros(nb,1));
 Qload(pq_data(:,1))= pq_data(:,3);
end

if (Freq_bit~=0)
 load freq_model.dat;
  
 R = freq_model(1);
 Kpf = freq_model(2);
 Kqf = freq_model(3);
 PG_sl = freq_model(4);
 delF = 0;
 
 if (Load_bit==0)
  PLo = sparse(zeros(nb,1));
  QLo = sparse(zeros(nb,1));
  PLo(load_data(:,1)) = load_data(:,2);
  QLo(load_data(:,1)) = load_data(:,3);
 end
end 

pv_Vmag =sparse(zeros(nb,1));
pv_Vmag(pv_data(:,1))= pv_data(:,2);

if (Q_bit~=0)
  QLlim = sparse(zeros(nb,1)); 
  QUlim = sparse(zeros(nb,1));
  QLlim(pv_data(:,1))=-9999;
  QUlim(pv_data(:,1))=9999;
  QUlim(Qlim_data(:,1)) = Qlim_data(:,3); 
  QLlim(Qlim_data(:,1)) = Qlim_data(:,2);          
end
  
%-----------------call fdlf_jacob_form.m to obtain the bus voltages----------%
  
  fdlf_jacob_form;
  
%-------------------perform the power flow calculations----------------%
  
  powerflow;     
  
%-------------------prepare the lfl.dat and report.dat--------------------------%
  lfl_result
  
if (convergence_bit==1)
 fprintf('\n\n Please wait... \n\n')    
 disp('Solution Converged !!!' );
else
 disp('Convergence is not reached !!!' );
end

elapsed_time = etime(clock,t0)
disp('See file: report.dat for details' );
