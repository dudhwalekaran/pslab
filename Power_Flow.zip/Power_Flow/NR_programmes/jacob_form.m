%~~~~~~~~~~~~~~~~~~~~Form Jacobian and solve for bus voltages and angles~~~~~~~~~~%
G=real(Y);
B=imag(Y);
theta_pq = sparse(zeros(nb,nb));
VpVq = sparse(zeros(nb,nb));
Vmag=sparse(ones(nb,1));
Vang=sparse(zeros(nb,1));
Vmag(pv_data(:,1))=pv_data(:,2);  %Replaces the voltages of P-V buses in Vmag 

Vmag(sl) = Vsl;
Vang(sl) = 0;
fid=fopen('report.dat', 'w');
fprintf(fid,'                   Detailed Report of Load flow (NR method)\n' ); 
fprintf(fid,'                   ----------------------------\n' );
%------------------Iteration begins from here onwards---------------------%
for k=1:10
   Vbus=Vmag.*(cos(Vang)+ j*sin(Vang));
%----------------------------------bus powers calculations------------------------%
   S=Vbus.*(conj(Y*Vbus));
   Pc=real(S);
   Qc=imag(S);
 %---------------------------------finding non slack and non pv buses------------------%
   pv_num=pv_data(:,1);
   pv_sl_num=[pv_num;sl];
   num_no_sl_pv =[1:nb]'; 
   num_no_sl_pv(pv_sl_num,:)=[];
   
   %-----------Perform the following if Q-limit is accounted--------------%
   start_cri=2;
   if (Q_bit~=0 &k>start_cri)
     Qc(pvpq_buses) = Qc(pvpq_buses) + Qload(pvpq_buses); 
     
 %-----------------------checking Qlimit voilation-----------------------------%
     pv_num_Uvio=sparse(zeros(nb,1));
     pv_num_Lvio=sparse(zeros(nb,1));
      
      if (sum(Qc(pv_num)>QUlim(pv_num))>=1)
        pv_num_Uvio(pv_num)=[Qc(pv_num)>QUlim(pv_num)];
        
        pv_num=[pv_num(Qc(pv_num)<QUlim(pv_num))];
        pv_sl_num=[pv_num;sl];
        num_no_sl_pv = [1:nb]';
        num_no_sl_pv(pv_sl_num,:)=[];
      end
        
      if (sum(Qc(pv_num)<QLlim(pv_num))>=1)
        pv_num_Lvio(pv_num) =[Qc(pv_num)<QLlim(pv_num)];
           
        pv_num=[pv_num(Qc(pv_num)>QLlim(pv_num))];
        pv_sl_num=[pv_num;sl];
        num_no_sl_pv = [1:nb]';
        num_no_sl_pv(pv_sl_num,:)=[];
      end
     
     Qsp = sparse(zeros(nb,1));
     Qsp(pq_data(:,1)) = -pq_data(:,3);
     Qsp = Qsp + (pv_num_Uvio.*QUlim)+ (pv_num_Lvio.*QLlim);
     
     Vmag(pv_num)=pv_Vmag(pv_num);  %Again Replace the voltages of P-V buses in Vmag 
     
 %----------------------------------Re-calculation of bus powers --------------------%
     Vbus=Vmag.*(cos(Vang)+ j*sin(Vang));
     S=Vbus.*(conj(Y*Vbus));
     Pc=real(S);
     Qc=imag(S);
   end       %-------Q-limit part ends here---------------
   
  %------------------------bus power mis matches -------------%
   delP=Psp-Pc;
   delP(sl,:)=[];
   delQ=Qsp-Qc;
   delQ(pv_sl_num,:)=[];
   del_PQ=[delP;delQ]; 
   
   if (max(abs(del_PQ))<= tole)
     convergence_bit=1;
     S(sl)= S(sl)+(sl_load(1,2)+j*sl_load(1,3));
     fprintf(fid,'__________________________________________________________________________\n');
     fprintf(fid,'Converged loadflow iteration No = %i, Max. mismatch = %10.8f\n',k-1, full(max(abs(del_PQ))));
     fprintf(fid,'----------------------------------\n'); 
     break;
   else
      del_Pm=sparse(zeros(nb,1)); 
      del_Qm=sparse(zeros(nb,1));
      del_Pm(sort([pv_num;num_no_sl_pv]))=delP;
      del_Qm(num_no_sl_pv)=delQ;
      Bno=[1:nb]';
      
      if (max(abs(del_Pm))>=max(abs(del_Qm)))
         vio_busP = Bno(abs(del_Pm)==max(abs(del_Pm)));
         if (k~=1)
           fprintf(fid,'Iter. No = %i Max. Real power mismatch at bus = %i, Max. mismatch = %10.8f\n',(k-1),full(vio_busP),full(max(abs(del_Pm))));
         end  
      else
         vio_busP=Bno(abs(del_Qm)==max(abs(del_Qm)));
         if (k~=1)
           fprintf(fid,'Iter. No = %i Max. Reactive power mismatch at bus = %i, Max. mismatch = %10.8f\n',(k-1),full(vio_busP),full(max(abs(del_Qm))));
         end    
      end
   end
      
 %--------------------------------calculation of Jacobian elements-----------%
   for i=1:nline+ntrans
     theta_pq(nt(i,1),nt(i,2))=Vang(nt(i,1))- Vang(nt(i,2));
     theta_pq(nt(i,2),nt(i,1))=Vang(nt(i,2))- Vang(nt(i,1));
     VpVq(nt(i,1),nt(i,2)) = Vmag(nt(i,1))* Vmag(nt(i,2));
     VpVq(nt(i,2),nt(i,1)) = VpVq(nt(i,1),nt(i,2));
   end
   
%---------------------------------------off diagonal------------------------%
   Hpq=VpVq.*(G.*sin(theta_pq)-B.*cos(theta_pq));
   Npq=VpVq.*(G.*cos(theta_pq)+B.*sin(theta_pq));
   
%---------------------------diagonal---------------------------------------%
   Hpp=-Qc-(diag(B).*(Vmag.*Vmag));
   Lpp=-Hpp-2*diag(B).*(Vmag.*Vmag);
   Npp=Pc+diag(G).*(Vmag.*Vmag);
   Mpp=Npp-2*diag(G).*(Vmag.*Vmag);
%----------------------------------H matrix--------------------------------%
   H=Hpq+sparse(diag(Hpp));
%---------------------------------L martrix--------------------------------%
   L=Hpq+sparse(diag(Lpp));
%---------------------------------N matrix---------------------------------%
   N=Npq+sparse(diag(Npp));
%---------------------------------M matrix---------------------------------%
   M=(-Npq)+sparse(diag(Mpp));
%---------------------------formation of jacobian matrix-------------------%
   H(sl,:)=[];
   H(:,sl)=[];
   L(:,pv_sl_num)=[];
   L(pv_sl_num,:)=[];
   N(:,pv_sl_num)=[];
   N(sl,:)=[];
   M(pv_sl_num,:)=[];
   M(:,sl)=[];
   J=[H N;M L];
%----------------------Calculation of correction vectors----------------%
   delx=J\del_PQ;
%----------------------Updation of bus angles at each bus----------------% 
   Vang(num_nosl)=Vang(num_nosl)+ delx(1:nb-1);
   
%----------------------Updation of bus voltages at each bus----------------% 
   
   del_Vmag=delx(nb:size(delx,1)).*Vmag(num_no_sl_pv);
   Vmag(num_no_sl_pv)=Vmag(num_no_sl_pv) + del_Vmag;
end
fclose(fid);

